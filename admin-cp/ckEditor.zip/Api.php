<?php

function getAllPlans(){
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [
        "admin"=>true
        ];
    
    $url = API_URL."getallplans";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;


}

function getAllUsers()
{
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [];
    
    $url = API_URL."getallusers";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;
}


function ApiRequest($data,$headers,$url)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $return = curl_exec($ch);
    $json_data = json_decode($return, true);
      
    
    $curl_error = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  
    return $json_data;

}

function findPlan($allplans,$single_row)
{
    $plan_id = $single_row['plan'];
    $i =0;

    $output = "Unknown";

    for( $i;$i<count($allplans);$i++){
        if($allplans[$i]['id']==$plan_id){
            $output = $allplans[$i]['name'];
            break;
        }

    }


    echo $output;

}

function getAllRefundRequests(){
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [
        "show_all"=>true
    ];
    
    $url = API_URL."getallrefundrequests";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;


}

function getAllAdminWallets(){
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [];
    
    $url = API_URL."getadminwallets";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;

}

function getAllPurchaseRequests()
{
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [];
    
    $url = API_URL."getallbuyrequests";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;
}

function getallWithdrawalRequests(){
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = [];
    
    $url = API_URL."getalltransections";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;

}

function getPlanInfo($id){
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = ["id"=>$id];
    
    $url = API_URL."getplandetails";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;

}

function getuserDetails($id)
{
    $headers = [
        "Accept: application/json",
        "Content-Type: application/json",
        
    ];
    
    $data = ["id"=>$id];
    
    $url = API_URL."getuserdetails";

    //echo encrypt_password($password);

    $json_data = ApiRequest($data,$headers,$url);

    if($json_data['code']=="200"){
        $output=$json_data['msg'];

    }else{
        $output=[];

    }
    return $output;

}

function getWalletAddressDetails($id){
    $all = getAllAdminWallets();

    for($i=0;$i<count($all);$i++){
        if($all[$i]['id']==$id){
            return $all[$i];
            break;
        }

    }

    return null;

}

?>