<?php

@session_start();
@ini_set('session.gc_maxlifetime',12*60*60);
@ini_set('session.cookie_lifetime',12*60*60);

error_reporting(E_ALL);

define('PRE_FIX' , "prohash_");


//Access Your API URL in browser and you will get a code to put over here that will be something like this https://prnt.sc/w309sg

$baseurl= "http://prohash.io/api/";


//detailed path to web folder in server ex. /home/server/public_html/web/;
$HOME_PATH=__DIR__."/uploads/";


//dont change any thing here
$imagebaseurl=$baseurl;
$baseurl = $baseurl."api.php/";

define('homepath' , $HOME_PATH);
define('imagebaseurl' , $imagebaseurl);
define('API_URL',$baseurl);
define('HOME_PATH',$HOME_PATH);



/* 
if (@$_GET['p'] == "login") {
      
      $email = htmlspecialchars($_POST['email'], ENT_QUOTES);
      $password = @$_POST['password'];
      
      
      $headers = [
          "Accept: application/json",
          "Content-Type: application/json",
          "api-key: ".API_KEY." "
      ];
      
      $data = [
          "email" => $email,
          "password" => $password,
          "role"=> "admin"
      ];
      
      $ch = curl_init($baseurl . 'login');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
      curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      $return = curl_exec($ch);
      $json_data = json_decode($return, true);
        
      
      $curl_error = curl_error($ch);
      $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      $data = $json_data['msg'];
   
      if ($json_data['code'] == 200) 
      {
        $_SESSION[PRE_FIX.'id'] = $json_data['msg']['Admin']['id'];
        $_SESSION[PRE_FIX.'role'] = $json_data['msg']['Admin']['role'];
        echo "<script>window.location='dashboard.php?p=users'</script>";
      }
      else 
      {
        echo "<script>window.location='index.php?action=error'</script>";
      }
      
}
*/
if(@$_GET['p'] == "logout" ) 
{ 
	@session_destroy();
	echo "<script>window.location='index.php'</script>";
}


?>
