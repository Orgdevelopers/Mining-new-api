<?php 
include("header.php"); 
if(isset($_SESSION[PRE_FIX.'id']))
{
?>
<div class="mainwrapper allusers">
    <div class="qr-layout">
	
	<?php require_once("rightsidebar.php"); ?>
	
		<?php 
		
		if(isset($_GET['p']) ) 
		{ 
		    if( $_GET['p'] == "plans" ) 
           	{ 
    			include("allplans.php");
    		}
    		
    		if( $_GET['p'] == "users" ) 
           	{ 
    			include("users.php");
    		}
    		
    		if( $_GET['p'] == "refundcontroller" ) 
           	{ 
    			include("refundcontroller.php");
    		}
    		
    		if( $_GET['p'] == "walletaddress" ) 
           	{ 
    			include("walletaddress.php");
    		}
    		
    		if( $_GET['p'] == "purchaserequests" ) 
           	{ 
    			include("purchaserequests.php");
    		}
    		
    		if( $_GET['p'] == "withdrawalrequests" ) 
           	{ 
    			include("withdrawalrequests.php");
    		}
    		
    		// if( $_GET['p'] == "review_aps" ) 
           	// { 
    		// 	include("review_apps.php");
    		// }

			// if( $_GET['p'] == "editappimages"){
			// 	include("editappimages.php");
			// }
    		
		}else{
			echo "<script>window.location='dashboard.php?p=plans'</script>";
		}
		
		?>
	</div>
</div>

<?php 
require_once("footer.php"); 
}
else
{
    echo "<script>window.location='index.php'</script>";
}


?>