
<?php
//include("header.php");
?>

<div class="qr-sidebar">
    <div class="qr-sidebar-title-area">
        <div class="logo-area">
            <div class="qr-logo">
                <a href="#"> <img src="frontend_public/uploads/attachment/main_logo.png" alt=""> </a>
            </div>
        </div>
        <div class="burger-icon"> ☰</div>
    </div>

  
        <div class="not-mobile">
            <ul>
                
                <li>
                    <a href="dashboard.php?p=plans" class="<?php if (strpos($_SERVER['REQUEST_URI'], "plans") !== false) { echo "router-link-active ";} ?>"> 
                    <i class="fas fa-tasks"></i> Plans
                    </a>
                </li>
            
                <li>
                    <a href="dashboard.php?p=users" class="<?php if (strpos($_SERVER['REQUEST_URI'], "users") !== false) { echo "router-link-active ";} ?>"> 
                    <i class="fa-solid fa-users"></i> Users
                    </a>
                </li>

                <li>
                    <a href="dashboard.php?p=refundcontroller" class="<?php if (strpos($_SERVER['REQUEST_URI'], "refundcontroller") !== false) { echo "router-link-active ";} ?>"> 
                    <i class="fa-solid fa-hand-holding-dollar"></i> Refund Controller
                    </a>

                </li>


                <li>
                    <a href="dashboard.php?p=walletaddress" class="<?php if (strpos($_SERVER['REQUEST_URI'], "walletaddress") !== false) { echo "router-link-active ";} ?>"> 
                    <i class="fa-solid fa-wallet"></i> Wallet Address
                    </a>
                </li>
                
                
                <li>
                    <a href="dashboard.php?p=purchaserequests" class="<?php if (strpos($_SERVER['REQUEST_URI'], "purchaserequests") !== false) { echo "router-link-active ";} ?>"> 
                        <i class="fa-solid fa-credit-card"></i> Purchase Requests
                    </a>
                </li>
            

                <li>
                    <a href="dashboard.php?p=withdrawalrequests" class="<?php if (strpos($_SERVER['REQUEST_URI'], "withdrawalrequests") !== false) { echo "router-link-active ";} ?>"> 
                        <i class="fa-solid fa-landmark"></i> Withdrawal requests
                    </a>
                </li>

            
                
                <li>
                    <a href="dashboard.php?p=logout" class="<?php if (strpos($_SERVER['REQUEST_URI'], "logout") !== false) { echo "router-link-active ";} ?>"> 
                        <i aria-hidden="true" class="right-align fa fa-sign-out-alt"></i> Logout
                    </a>
                </li>
                
            </ul>
            <div class='clear'></div>
        </div>
        <div class="mobile-only"></div>
        
</div>